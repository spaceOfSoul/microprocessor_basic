﻿/*
 * adc_util.h
 *
 * Created: 2023-11-30 오후 1:21:19
 *  Author: 유창현
 */ 


void adc_init(void);
uint16_t adc_get_result(uint8_t channel_num);
